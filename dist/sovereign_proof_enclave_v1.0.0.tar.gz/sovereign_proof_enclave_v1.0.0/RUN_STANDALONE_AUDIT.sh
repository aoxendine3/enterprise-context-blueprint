#!/bin/bash
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "================================================================================"
echo "    XORAS SOVEREIGN PROOF ENCLAVE: INDEPENDENT THIRD-PARTY AUDIT ENTRYPOINT     "
echo "================================================================================"
echo "Substrate: Independent POSIX / Apple Silicon / x86_64 Clean Room"
echo "Mission: Zero XORAS Swarm Code, Zero Repo Ambient State, 100% Standalone Proof."
echo "================================================================================"

echo -e "\n[*] STAGE 1: SMT-LIB v2 FORMAL BITVECTOR CONTAINMENT PROOF"
python3 "$DIR/PROOFS/verify_smt2_standalone.py"

echo -e "\n[*] STAGE 2: CRYPTOGRAPHIC EVIDENCE LEDGER VERIFICATION (30 ROWS)"
python3 "$DIR/LEDGER/verify_ledger_standalone.py"

echo -e "\n[*] STAGE 3: DETERMINISTIC CLEAN-ROOM COMPILER BUILD & REPRODUCIBILITY"
"$DIR/SOVRAC_COMPILER/build_deterministic.sh"

echo -e "\n[*] STAGE 4: POLYGLOT MULTI-LANGUAGE CONTAINMENT HARNESS"
"$DIR/POLYGLOT_SOURCES/build_and_run_all.sh"

echo -e "\n================================================================================"
echo ">>> ALL 4 INDEPENDENT VERIFICATION STAGES PASSED: 100.00% EMPIRICAL RIGOR."
echo ">>> THE PROOF ENCLAVE STANDS ALONE WITHOUT SWARM, REPO, OR AMBIENT AMNESIA."
echo "================================================================================"
