#!/bin/bash
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "================================================================================"
echo "           INDEPENDENT POLYGLOT CONTAINMENT BUILD & EXECUTION SUITE            "
echo "================================================================================"

echo "[1/4] Building & Running C11 POSIX..."
cd "$DIR/c11"
clang -O3 upgp_containment.c -o upgp_c
./upgp_c
echo "[PASS] C11 POSIX passed."

echo -e "\n[2/4] Building & Running Rust Typestate..."
cd "$DIR/rust"
rustc -O upgp_containment.rs -o upgp_rust
./upgp_rust
echo "[PASS] Rust Typestate passed."

echo -e "\n[3/4] Building & Running Zig Comptime Tagged Union..."
cd "$DIR/zig"
ZIG_CMD="$(which zig 2>/dev/null || echo '/opt/homebrew/bin/zig')"
"$ZIG_CMD" build-exe -O ReleaseFast upgp_containment.zig -femit-bin=upgp_zig
./upgp_zig
echo "[PASS] Zig Comptime passed."

echo -e "\n[4/4] Running Python 3.14 + Z3..."
cd "$DIR/python"
python3 upgp_containment.py
echo "[PASS] Python Z3 passed."

echo "================================================================================"
echo ">>> ALL POLYGLOT CONTAINMENT IMPLEMENTATIONS COMPILED & EXECUTED CLEANLY."
echo "================================================================================"
