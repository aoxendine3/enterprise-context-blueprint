#!/usr/bin/env python3
"""
dist/sovereign_proof_enclave_v1.0.0/PROOFS/verify_smt2_standalone.py
=============================================================================
INDEPENDENT SMT-LIB v2 CONTAINMENT PROOF VERIFIER
-----------------------------------------------------------------------------
Reads upgp_containment_proof.smt2 directly.
Can be verified with:
- z3 (pip install z3-solver OR brew install z3)
- cvc5 (brew install cvc5)
- yices (brew install yices2)
- mathsat
=============================================================================
"""

import os
import sys

DIR = os.path.dirname(os.path.abspath(__file__))
SMT2_FILE = os.path.join(DIR, "upgp_containment_proof.smt2")

def main():
    print("=" * 75)
    print("       INDEPENDENT SMT-LIB v2 FORMAL CONTAINMENT PROOF VERIFIER       ")
    print("=" * 75)
    print(f"[*] Reading SMT-LIB v2 proof: {SMT2_FILE}")

    import subprocess, shutil
    z3_bin = shutil.which("z3")
    if z3_bin:
        print(f"[*] Found raw upstream Z3 binary at {z3_bin}")
        res = subprocess.run([z3_bin, SMT2_FILE], capture_output=True, text=True)
        out = res.stdout.strip()
        print(f"[+] Z3 Solver Raw Output: '{out}'")
        if out == "unsat":
            print(">>> VERIFICATION SUCCESS: RAW Z3 RETURNED 'UNSAT'.")
            print(">>> PROOF: NO ESCAPE PATHWAY EXISTS IN THE ORTHOGONAL BITVECTOR LATTICE.")
            print("=" * 75)
            sys.exit(0)
        else:
            print(f"❌ UNEXPECTED RESULT: '{out}' (Must be unsat)")
            sys.exit(1)

    try:
        import z3
        s = z3.Solver()
        assertions = z3.parse_smt2_file(SMT2_FILE)
        s.add(assertions)
        res = s.check()
        print(f"[+] Python Z3 Solver Verification Result: {res}")
        if res == z3.unsat:
            print(">>> VERIFICATION SUCCESS: SATISFIABILITY IS 'UNSAT'.")
            print(">>> PROOF: NO ESCAPE PATHWAY EXISTS IN THE ORTHOGONAL BITVECTOR LATTICE.")
            print("=" * 75)
            sys.exit(0)
        else:
            print(f"❌ UNEXPECTED RESULT: {res} (Must be unsat)")
            sys.exit(1)
    except ImportError:
        print("[!] Neither raw z3 binary nor python z3-solver module found.")
        print("[*] Install Z3 via: brew install z3 (or apt install z3 / pip install z3-solver)")
        print(f"    Then execute: z3 {SMT2_FILE}")
        sys.exit(1)

if __name__ == "__main__":
    main()
