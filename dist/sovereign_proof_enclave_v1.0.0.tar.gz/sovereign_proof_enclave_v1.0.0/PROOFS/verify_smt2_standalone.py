#!/usr/bin/env python3
"""
dist/sovereign_proof_enclave_v1.0.0/PROOFS/verify_smt2_standalone.py
=============================================================================
INDEPENDENT SMT-LIB v2 CONTAINMENT PROOF VERIFIER
-----------------------------------------------------------------------------
Reads upgp_containment_proof.smt2 directly.
Can be verified with:
- z3 (pip install z3-solver OR brew install z3)
- cvc5 (brew install cvc5)
- yices (brew install yices2)
- mathsat
=============================================================================
"""

import os
import sys

DIR = os.path.dirname(os.path.abspath(__file__))
SMT2_FILE = os.path.join(DIR, "upgp_containment_proof.smt2")

def main():
    print("=" * 75)
    print("       INDEPENDENT SMT-LIB v2 FORMAL CONTAINMENT PROOF VERIFIER       ")
    print("=" * 75)
    print(f"[*] Reading SMT-LIB v2 proof: {SMT2_FILE}")

    try:
        import z3
        s = z3.Solver()
        assertions = z3.parse_smt2_file(SMT2_FILE)
        s.add(assertions)
        res = s.check()
        print(f"[+] Z3 Solver Verification Result: {res}")
        if res == z3.unsat:
            print(">>> VERIFICATION SUCCESS: SATISFIABILITY IS 'UNSAT'.")
            print(">>> PROOF: NO ESCAPE PATHWAY EXISTS IN THE ORTHOGONAL BITVECTOR LATTICE.")
            print("=" * 75)
            sys.exit(0)
        else:
            print(f"❌ UNEXPECTED RESULT: {res} (Must be unsat)")
            sys.exit(1)
    except ImportError:
        print("[!] Python z3 module not installed.")
        print("[*] To verify with command-line solvers:")
        print(f"    z3 {SMT2_FILE}")
        print(f"    cvc5 {SMT2_FILE}")
        print(f"    yices-smt2 {SMT2_FILE}")
        sys.exit(0)

if __name__ == "__main__":
    main()
