#!/bin/bash
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "================================================================================"
echo "          SOVRAC v3.1 STANDALONE DETERMINISTIC COMPILER BUILDER                 "
echo "================================================================================"

SOURCE="$DIR/sovrac_v3_1.zig"
OUT_BIN="$DIR/sovrac"
EXPECTED_SHA="7a64443648e2a9f9603b7700b461e871cec0ec01809e2896043064c487e8d451"

ZIG_CMD="$(which zig 2>/dev/null || true)"
if [ -z "$ZIG_CMD" ] || [ ! -x "$ZIG_CMD" ]; then
    if [ -x "/opt/homebrew/bin/zig" ]; then
        ZIG_CMD="/opt/homebrew/bin/zig"
    elif [ -x "$HOME/.zig-0.16.0/zig" ]; then
        ZIG_CMD="$HOME/.zig-0.16.0/zig"
    elif [ -x "$DIR/install_pinned_zig.sh" ]; then
        echo "[*] Zig not detected in PATH. Executing zero-trust digest-pinned bootstrap..."
        bash "$DIR/install_pinned_zig.sh" "$DIR/zig_bin"
        ZIG_CMD="$DIR/zig_bin/zig"
    fi
fi

if [ -z "$ZIG_CMD" ] || [ ! -x "$ZIG_CMD" ]; then
    echo "❌ FATAL: Zig 0.16.0 binary not found and bootstrap unavailable."
    exit 1
fi

echo "[*] Compiler binary: $ZIG_CMD ($("$ZIG_CMD" version))"
echo "[*] Compiling with Pinned Deterministic Flags:"
echo "    -O ReleaseFast -fstrip -fno-incremental"
"$ZIG_CMD" build-exe -O ReleaseFast -fstrip -fno-incremental "$SOURCE" -femit-bin="$OUT_BIN"

ACTUAL_SHA=$(shasum -a 256 "$OUT_BIN" | awk '{print $1}')
echo "[*] Output Binary SHA-256: $ACTUAL_SHA"
echo "[*] Expected Lockfile SHA: $EXPECTED_SHA"

if [ "$ACTUAL_SHA" == "$EXPECTED_SHA" ]; then
    echo ">>> SUCCESS: BIT-FOR-BIT DETERMINISTIC MATCH PROVEN."
    echo "================================================================================"
    exit 0
else
    echo "❌ ERROR: HASH DIVERGENCE DETECTED!"
    echo "================================================================================"
    exit 1
fi
