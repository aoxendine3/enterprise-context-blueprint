#!/bin/bash
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "================================================================================"
echo "          SOVRAC v3.1 STANDALONE DETERMINISTIC COMPILER BUILDER                 "
echo "================================================================================"

SOURCE="$DIR/sovrac_v3_1.zig"
OUT_BIN="$DIR/sovrac"
EXPECTED_SHA="7a64443648e2a9f9603b7700b461e871cec0ec01809e2896043064c487e8d451"

echo "[*] Compiling with Pinned Deterministic Flags:"
echo "    -O ReleaseFast -fstrip -fno-incremental"
/opt/homebrew/bin/zig build-exe -O ReleaseFast -fstrip -fno-incremental "$SOURCE" -femit-bin="$OUT_BIN"

ACTUAL_SHA=$(shasum -a 256 "$OUT_BIN" | awk '{print $1}')
echo "[*] Output Binary SHA-256: $ACTUAL_SHA"
echo "[*] Expected Lockfile SHA: $EXPECTED_SHA"

if [ "$ACTUAL_SHA" == "$EXPECTED_SHA" ]; then
    echo ">>> SUCCESS: BIT-FOR-BIT DETERMINISTIC MATCH PROVEN."
    echo "================================================================================"
    exit 0
else
    echo "❌ ERROR: HASH DIVERGENCE DETECTED!"
    echo "================================================================================"
    exit 1
fi
