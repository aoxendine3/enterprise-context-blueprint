#!/usr/bin/env python3
"""
dist/sovereign_proof_enclave_v1.0.0/LEDGER/verify_ledger_standalone.py
=============================================================================
STANDALONE EVIDENCE LEDGER VERIFICATION HARNESS
-----------------------------------------------------------------------------
Zero reliance on XORAS repo structure, swarm state, or environment variables.
Verifies:
1. Append-only sequence numbers (seq 0 to N with 0 gaps).
2. Hash chain integrity: each row's prev_hash == previous row's row_hash.
3. Row canonical hash calculation.
4. Cryptographic Ed25519 signatures against agent public keys in pubkeys/.
=============================================================================
"""

import hashlib
import json
import os
import sys
from cryptography.hazmat.primitives import serialization

DIR = os.path.dirname(os.path.abspath(__file__))
LEDGER_PATH = os.path.join(DIR, "evidence_ledger.jsonl")
PUBKEY_DIR = os.path.join(DIR, "pubkeys")
GENESIS = "0" * 64

def canon(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()

def load_pubkey(agent):
    p = os.path.join(PUBKEY_DIR, agent, "ed25519_pub.pem")
    if not os.path.exists(p):
        raise FileNotFoundError(f"Missing public key for agent {agent} at {p}")
    with open(p, "rb") as f:
        return serialization.load_pem_public_key(f.read())

def verify_standalone():
    print("=" * 75)
    print("      STANDALONE CRYPTOGRAPHIC EVIDENCE LEDGER VERIFICATION      ")
    print("=" * 75)

    if not os.path.exists(LEDGER_PATH):
        print(f"❌ Ledger file not found at {LEDGER_PATH}")
        sys.exit(1)

    rows = []
    with open(LEDGER_PATH) as f:
        for line in f:
            if line.strip():
                rows.append(json.loads(line))

    print(f"[*] Loaded {len(rows)} cryptographically signed ledger rows.")
    prev_hash = GENESIS
    problems = []

    for idx, r in enumerate(rows):
        seq = r.get("seq")
        agent = r.get("agent")
        subject = r.get("subject")
        row_hash = r.get("row_hash")
        sig_hex = r.get("sig")
        prev = r.get("prev_hash")

        # 1. Sequence check
        if seq != idx:
            problems.append((idx, f"SEQ_GAP: expected {idx}, got {seq}"))

        # 2. Chain hash check
        if prev != prev_hash:
            problems.append((idx, f"CHAIN_BREAK: prev_hash {prev[:12]} != {prev_hash[:12]}"))

        # 3. Canonical hash check
        body = {k: v for k, v in r.items() if k not in ("row_hash", "sig")}
        computed_hash = hashlib.sha256(canon(body)).hexdigest()
        if computed_hash != row_hash:
            problems.append((idx, "ROW_HASH_MISMATCH: content has been altered!"))

        # 4. Signature check
        try:
            pub = load_pubkey(agent)
            pub.verify(bytes.fromhex(sig_hex), bytes.fromhex(row_hash))
            sig_ok = True
        except Exception as e:
            sig_ok = False
            problems.append((idx, f"BAD_SIGNATURE: failed Ed25519 verification for {agent} ({e})"))

        status = "OK" if sig_ok and computed_hash == row_hash and prev == prev_hash else "FAIL"
        print(f"  [{idx:02d}] {agent:<6} | {subject:<42} | hash:{row_hash[:12]}.. | {status}")
        prev_hash = row_hash

    print("\n" + "=" * 75)
    if not problems:
        print(f">>> ALL {len(rows)} ROWS VERIFIED: ZERO CHAIN BREAKS, ZERO FORGED SIGNATURES.")
        print(">>> THE CRYPTOGRAPHIC EVIDENCE CHAIN IS 100.00% TAMPER-EVIDENT.")
        print("=" * 75)
        return True
    else:
        print(f"❌ {len(problems)} TAMPERING PROBLEMS DETECTED:")
        for seq, why in problems:
            print(f"    - Row {seq}: {why}")
        print("=" * 75)
        return False

if __name__ == "__main__":
    if not verify_standalone():
        sys.exit(1)
